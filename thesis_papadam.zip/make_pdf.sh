#!/bin/bash

make clean

make

make bib

make

make

make
